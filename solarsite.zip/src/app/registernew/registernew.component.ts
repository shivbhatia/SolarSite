import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'registernew',
  templateUrl: "./registernew.html",
  styleUrls:['../../assets/cssnew/bootstrap.min.css'],
  
})

export class RegisternewComponent{
	constructor(private router: Router) { 
	}

  ngOnInit(){
  }
}
	


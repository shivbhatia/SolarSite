import { RegisternewComponent } from "./registernew.component";
//import { LandingComponent } from "./landing.component";

export const registernewRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/registrationnew', component: RegisternewComponent }
];

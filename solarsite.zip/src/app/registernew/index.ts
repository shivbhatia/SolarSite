import { RegisternewComponent } from './registernew.component';
//import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const REGISTERNEW_DECLARATIONS = [
	RegisternewComponent,
//	registerheaderComponent
	//HeaderComponent
];



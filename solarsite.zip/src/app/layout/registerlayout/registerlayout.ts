import { registerheaderComponent } from './registerheader/registerheader.component';

export const REGISTERLAYOUT_DECLARATIONS = [
	registerheaderComponent
];

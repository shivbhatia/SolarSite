import { Component } from '@angular/core';

@Component({
  selector: 'registerheader',
  templateUrl: "./registerheader.html"
})
export class registerheaderComponent {
}

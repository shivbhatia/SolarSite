import { HOMELAYOUT_DECLARATIONS } from './homelayout/homelayout';
import { REGISTERLAYOUT_DECLARATIONS } from './registerlayout/registerlayout';


export const LAYOUT_DECLARATIONS = [
	HOMELAYOUT_DECLARATIONS,
	REGISTERLAYOUT_DECLARATIONS
];

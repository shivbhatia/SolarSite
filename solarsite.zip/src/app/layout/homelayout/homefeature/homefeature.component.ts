import { Component } from '@angular/core';

@Component({
  selector: 'homefeature',
  templateUrl: "./homefeature.html",
  styleUrls:[],
})
export class homefeatureComponent {
}

import { Component } from '@angular/core';

@Component({
  selector: 'homemenu',
  templateUrl: "./homemenu.html",
  	
})
export class homemenuComponent {
}

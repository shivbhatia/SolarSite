import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'homefooter',
  templateUrl: "./homefooter.html"
})
export class homefooterComponent {
	constructor(private router: Router) {
    
   }
}

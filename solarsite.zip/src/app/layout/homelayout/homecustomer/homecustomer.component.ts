import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'homecustomer',
  templateUrl: "./homecustomer.html"
})
export class homecustomerComponent {
	constructor(private router: Router) {
    
   }
}

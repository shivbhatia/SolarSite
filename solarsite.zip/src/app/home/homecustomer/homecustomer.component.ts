import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'homecustomer',
  templateUrl: "./homecustomer.html",
  styleUrls:['../../../assets/css/home/style.css'],
})
export class homecustomerComponent {
	constructor(private router: Router) {
    
   }
}

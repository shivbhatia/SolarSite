import { Component } from '@angular/core';

@Component({
  selector: 'homefeature',
  templateUrl: "./homefeature.html",
  styleUrls:['../../../assets/css/home/style.css'],
})
export class homefeatureComponent {
}

import { Component, OnInit } from '@angular/core';

@Component({
	selector:'home',
	templateUrl:'./home.html',
	//styleUrls:['../../assets/css/home/style.css','../../assets/cssnew/bootstrap.min.css'],
})

export class homeComponent implements OnInit {
	ngOnInit() {

	}
}
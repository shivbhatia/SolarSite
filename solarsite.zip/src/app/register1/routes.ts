import { RegisterComponent } from "./register.component";
//import { LandingComponent } from "./landing.component";

export const registerRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/registration', component: RegisterComponent }
];

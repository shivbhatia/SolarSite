import { LoginComponent } from "./login.component";
//import { LandingComponent } from "./landing.component";

export const loginRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/login', component: LoginComponent }
];

import { LoginComponent } from './login.component';
//import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const LOGIN_DECLARATIONS = [
	LoginComponent,
//	registerheaderComponent
	//HeaderComponent
];



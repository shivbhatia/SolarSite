import { DashboardComponent } from "./dashboard.component";
//import { LandingComponent } from "./landing.component";

export const dashboardRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/dashboard', component: DashboardComponent }
];

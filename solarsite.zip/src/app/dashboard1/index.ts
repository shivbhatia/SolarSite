import { DashboardComponent } from './dashboard.component';
//import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const DASHBOARD_DECLARATIONS = [
	DashboardComponent,
//	registerheaderComponent
	//HeaderComponent
];



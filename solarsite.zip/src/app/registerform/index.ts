import { RegisterformComponent } from './registerform.component';
//import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const REGISTERFORM_DECLARATIONS = [
	RegisterformComponent,
//	registerheaderComponent
	//HeaderComponent
];



import { RegisterformComponent } from "./registerform.component";
//import { LandingComponent } from "./landing.component";

export const registerformRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/registrationform', component: RegisterformComponent }
];

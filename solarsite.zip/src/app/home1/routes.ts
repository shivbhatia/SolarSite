import { HomeComponent } from "./home.component";
//import { LandingComponent } from "./landing.component";

export const homeRoutes = [
//{ path: '', component: LandingComponent },
{ path: '', component: HomeComponent }
];

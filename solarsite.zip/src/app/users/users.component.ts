import { Component, OnInit } from '@angular/core';

@Component({
	selector:'users',
	templateUrl:'./users.html',
	//styleUrls:['../../assets/css/home/style.css','../../assets/cssnew/bootstrap.min.css'],
})

export class usersComponent implements OnInit {
	ngOnInit() {

	}
	
}
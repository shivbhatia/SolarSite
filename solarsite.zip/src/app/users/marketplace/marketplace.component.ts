import { Component,ViewEncapsulation,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { SolarService } from '../../services/solar.service';
import { Solar } from '../../models/solar.model';
import {DataTableModule,SharedModule} from 'primeng/primeng';

@Component({
    templateUrl: "./marketplace.html",
})

export class marketplaceComponent implements OnInit{
    model: any = {};
    result : any;
    token : any;
    public message = '';
    private toasterService: ToasterService;
    isLoading: boolean = false;
    pageLinks:any;
    rowsPerPageOptions: number[] = [];
    perPage:number=0;  
    recordsPerPage:number=25;

    //center:any;
    mapTypeId:any;
    private map: any;
    markers:any;
    marker:any;
    icon:string;

    constructor(private router: Router,private solarService: SolarService, toasterService: ToasterService) { 
        this.toasterService = toasterService;
    }

    ngOnInit(){
        $('#mydiv').show();
        this.solarService.get(<Solar>this.model).subscribe(result => {
            this.result = result.data;
            this.markers=result.markers;
            this.pageLinks=Math.ceil(result.data.length/this.recordsPerPage);
            for (let i=1; i<=this.pageLinks; i++) {
                this.perPage=this.perPage+this.recordsPerPage;
                this.rowsPerPageOptions.push(this.perPage);
            }
            $('#mydiv').hide();
            if (result.success == true) {
                alert("User added"); 
            } else {
              //alert("Not added");
            }
        });


        /********************* MAP START **************************/

         var map;
    var bounds = new google.maps.LatLngBounds();
    
    
   var center = new google.maps.LatLng(37.09024, -95.712891);
    var mapOptions = {
            //mapTypeId: 'roadmap',
            zoom: 7,
            center: center,
            mapTypeControl: false,
            maxZoom : 10
        };
    
                    
    // Display a map on the page
   this.map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
    map.setTilt(45);
       
    // Display multiple markers on a map
    var infoWindow = new google.maps.InfoWindow(), marker, i;
    var icon_url = "http://maps.google.com/mapfiles/ms/micons/";
    
        
    // Loop through our array of markers & place each one on the map  
    for( i = 0; i < this.markers.length; i++ ) {
        var position = new google.maps.LatLng(this.markers[i][1], this.markers[i][2]);
        bounds.extend(position);

        console.log(this.markers[i][3]);
        
        //var icon = "";
        switch (this.markers[i][3]) {
            case "0":
                icon = "lightblue"; //array('0' => 'In Discussion', '1' => 'Working Model Presented', '2' => 'Letter of Intent', '3' => 'Qualified') ;
                break;
            case "1":
                icon = "orange";
                break;
            case "2":
                icon = "green";
                break;
            case "3":
                icon = "purple";
                break;
            case "user":
                icon = "sunny";
                //icon_url = "http://maps.google.com/mapfiles/ms/micons/" ;
                break;
            
        }
        
        icon = icon_url + icon + ".png";
        
        
        this.marker = new google.maps.Marker({
            position: position,
            map: map,
            title: this.markers[i][0],
            //icon: new google.maps.MarkerImage(icon)
        });
        
        // Allow each marker to have an info window    
       /* google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infoWindow.setContent(infoWindowContent[i][0]);
                infoWindow.open(map, marker);
            }
        })(marker, i));*/

        
        
        // Automatically center the map fitting all markers on the screen
        // map.fitBounds(bounds);
        // map.setCenter(marker.getPosition());
        
    }
    
    // Add the circle for this city to the map.
        var cityCircle = new google.maps.Circle({
            strokeColor: '#FF0000',
            strokeOpacity: 0.5,
            strokeWeight: 2,
            fillColor: '#FF0000',
            fillOpacity: 0.2,
            map: map,
            center: center, 
            radius: 160934 //80467.2
          });
        
    
    
    var legend = document.getElementById('legend');
    var icons = {
          '2': {
            name: 'In Discussion',
            icon: icon_url + 'lightblue.png',
            title: 'In Discussion: The trusted sales agent/originator has been meeting with the client to determine their energy needs, budget and to gather 12 months utility bills.'
          },
          '1': {
            name: 'Working Model Presented',
            icon: icon_url + 'orange.png',
            title: 'Working Model Presented: The trusted sales agent/originator has been meeting with the client to review the initial, preliminary drawings and estimate.'
          },
          '0': {
            name: 'Letter of Intent',
            icon: icon_url + 'green.png',
            title: 'Letter of Intent: The customer has acknowledged to their trusted sales agent/originator they would like to move forward with installing solar. This is the highest qualified lead you can access.'
          },
          '3': {
            name: 'Qualified',
            icon: icon_url + 'purple.png',
            title: 'Qualified: The trusted sales agent/originator has determined the property to be a good fit for solar, and are working to contact the decision makers about further interest.'
          },
          'user': {
            name: 'Your location',
            icon: icon_url + 'sunny.png',
            title: ''
          }
        };
    for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var title = type.title;
        var div = document.createElement('div');
        div.innerHTML = '<img src="' + icon + '" title="'+ title +'"> ' + name;
        legend.appendChild(div);
    } 
    map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(legend);
    
    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
    /* var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
        this.setZoom(4);
        google.maps.event.removeListener(boundsListener);
    }); 



        /********************* MAP END **************************/


    }
}
	


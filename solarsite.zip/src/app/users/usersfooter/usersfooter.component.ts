import { Component } from '@angular/core';

@Component({
  selector: 'usersfooter',
  templateUrl: "./usersfooter.html",
  //styleUrls:['../../../assets/css/home/style.css'],
})

export class usersfooterComponent {
}

import { RegisterComponent } from './register.component';
import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const REGISTER_DECLARATIONS = [
	RegisterComponent,
	registerheaderComponent
	//HeaderComponent
];



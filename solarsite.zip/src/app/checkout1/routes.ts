import { CheckoutComponent } from "./checkout.component";
//import { LandingComponent } from "./landing.component";

export const checkoutRoutes = [
//{ path: '', component: LandingComponent },
{ path: 'users/checkout', component: CheckoutComponent }
];

import { CheckoutComponent } from './checkout.component';
//import { registerheaderComponent } from '../layout/registerlayout/registerheader/registerheader.component';

export const CHECKOUT_DECLARATIONS = [
	CheckoutComponent,
//	registerheaderComponent
	//HeaderComponent
];



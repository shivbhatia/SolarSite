﻿export class Solar {
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    age: number;
    address: string;
}
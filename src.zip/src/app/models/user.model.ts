﻿export class User {
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    age: number;
    address: string;
}
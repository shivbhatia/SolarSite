export class AppSettings {
   public static API_ENDPOINT='http://192.155.246.146:8145/webservicesangular/';
}
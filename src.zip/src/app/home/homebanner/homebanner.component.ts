import { Component } from '@angular/core';

@Component({
  selector: 'homebanner',
  templateUrl: "./homebanner.html",
  styleUrls:['../../../assets/css/home/style.css'],
})

export class homebannerComponent {
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'homefooter',
  templateUrl: "./homefooter.html",
  styleUrls:['../../../assets/css/home/style.css'],
})
export class homefooterComponent {
	constructor(private router: Router) {
    
   }
}
